/**
 * WP S3 Backup — Admin JavaScript
 */
(function ($) {
    'use strict';

    var autoRefreshTimer = null;

    $(document).ready(function () {

        // ─── Test Connection ─────────────────────────

        $('#wps3b-test-connection').on('click', function (e) {
            e.preventDefault();

            var $btn = $(this);
            var $result = $('#wps3b-test-result');

            $btn.prop('disabled', true);
            $result
                .removeClass('wps3b-test-success wps3b-test-error')
                .text(wps3b_ajax.i18n.testing);

            $.ajax({
                url: wps3b_ajax.url,
                type: 'POST',
                data: {
                    action: 'wps3b_test_connection',
                    nonce: wps3b_ajax.nonce,
                },
                success: function (response) {
                    if (response.success) {
                        $result
                            .addClass('wps3b-test-success')
                            .text(response.data);
                    } else {
                        $result
                            .addClass('wps3b-test-error')
                            .text(response.data);
                    }
                },
                error: function () {
                    $result
                        .addClass('wps3b-test-error')
                        .text('Request failed. Please try again.');
                },
                complete: function () {
                    $btn.prop('disabled', false);
                },
            });
        });

        // ─── Credential Field Handling ───────────────

        $('#wps3b_access_key, #wps3b_secret_key').on('focus', function () {
            var val = $(this).val();
            if (val && val.indexOf('****') !== -1) {
                $(this).val('').attr('type', 'text');
            }
        });

        // ─── Log Refresh ─────────────────────────────

        function refreshLogs(showStatus) {
            var $container = $('#wps3b-log-container');
            var $status = $('#wps3b-refresh-status');
            var $icon = $('#wps3b-refresh-logs .wps3b-spin-icon');

            if (!$container.length) {
                return;
            }

            $icon.addClass('wps3b-spinning');

            if (showStatus) {
                $status
                    .removeClass('wps3b-refresh-done')
                    .text(wps3b_ajax.i18n.refreshing);
            }

            $.ajax({
                url: wps3b_ajax.url,
                type: 'POST',
                data: {
                    action: 'wps3b_get_logs',
                    nonce: wps3b_ajax.logs_nonce,
                },
                success: function (response) {
                    if (response.success) {
                        $container.html(response.data.html);

                        if (showStatus) {
                            var now = new Date();
                            var time = now.toLocaleTimeString();
                            $status
                                .addClass('wps3b-refresh-done')
                                .text(wps3b_ajax.i18n.updated + ' ' + time);
                        }
                    }
                },
                complete: function () {
                    $icon.removeClass('wps3b-spinning');
                },
            });
        }

        // Manual refresh button
        $('#wps3b-refresh-logs').on('click', function (e) {
            e.preventDefault();
            refreshLogs(true);
        });

        // Auto-refresh toggle
        $('#wps3b-auto-refresh').on('change', function () {
            if ($(this).is(':checked')) {
                refreshLogs(true);
                autoRefreshTimer = setInterval(function () {
                    refreshLogs(true);
                }, 5000);
            } else {
                if (autoRefreshTimer) {
                    clearInterval(autoRefreshTimer);
                    autoRefreshTimer = null;
                }
                $('#wps3b-refresh-status').text('');
            }
        });

        // Clean up on page leave
        $(window).on('beforeunload', function () {
            if (autoRefreshTimer) {
                clearInterval(autoRefreshTimer);
            }
        });
    });
})(jQuery);
