<?php
/**
 * Logs page view — displays backup activity log with live refresh.
 *
 * @package WP_S3_Backup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$entries = WPS3B_Logger::get_entries();
?>

<div class="wrap wps3b-wrap">
	<h1><?php esc_html_e( 'WP S3 Backup — Activity Log', 'wp-s3-backup' ); ?></h1>

	<div class="wps3b-log-controls">
		<button type="button" id="wps3b-refresh-logs" class="button button-secondary">
			<span class="dashicons dashicons-update wps3b-spin-icon"></span>
			<?php esc_html_e( 'Refresh', 'wp-s3-backup' ); ?>
		</button>
		<label class="wps3b-auto-refresh-label">
			<input type="checkbox" id="wps3b-auto-refresh" />
			<?php esc_html_e( 'Auto-refresh every 5 seconds', 'wp-s3-backup' ); ?>
		</label>
		<span id="wps3b-refresh-status"></span>
	</div>

	<div id="wps3b-log-container">
		<?php WPS3B_Logger::render_table( $entries ); ?>
	</div>
</div>
