<?php
/**
 * Backups page view — lists backups in S3 with download, delete, and restore actions.
 *
 * @package WP_S3_Backup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$has_creds      = WPS3B_Settings::has_credentials();
$backups        = array();
$error          = '';
$show_confirm   = isset( $_GET['wps3b_confirm_restore'] );
$restore_data   = get_transient( 'wps3b_restore_manifest' );

if ( $has_creds && ! $show_confirm ) {
	$result = WPS3B_Backup_Manager::list_backups();
	if ( is_wp_error( $result ) ) {
		$error = $result->get_error_message();
	} else {
		$backups = $result;
	}
}
?>

<div class="wrap wps3b-wrap">
	<h1><?php esc_html_e( 'WP S3 Backup — Backups', 'wp-s3-backup' ); ?></h1>

	<?php settings_errors( 'wps3b_backups' ); ?>

	<?php if ( ! $has_creds ) : ?>
		<div class="notice notice-warning">
			<p>
				<?php
				printf(
					/* translators: Settings page link */
					esc_html__( 'AWS credentials are not configured. %s to set them up.', 'wp-s3-backup' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=wps3b_settings' ) ) . '">' . esc_html__( 'Go to Settings', 'wp-s3-backup' ) . '</a>'
				);
				?>
			</p>
		</div>

	<?php elseif ( $show_confirm && $restore_data ) : ?>
		<!-- Restore Confirmation Screen -->
		<?php
		$timestamp = $restore_data['timestamp'];
		$manifest  = $restore_data['manifest'];
		$is_error  = is_wp_error( $manifest );
		$warnings  = ! $is_error && isset( $manifest['warnings'] ) ? $manifest['warnings'] : array();
		?>

		<div class="wps3b-restore-confirm">
			<h2><?php esc_html_e( 'Confirm Restore', 'wp-s3-backup' ); ?></h2>

			<div class="notice notice-warning">
				<p><strong><?php esc_html_e( 'Warning: This will replace your entire database and wp-content directory.', 'wp-s3-backup' ); ?></strong></p>
				<p><?php esc_html_e( 'Your wp-config.php and WordPress core files will NOT be modified.', 'wp-s3-backup' ); ?></p>
			</div>

			<?php if ( $is_error ) : ?>
				<div class="notice notice-error">
					<p><?php echo esc_html( $manifest->get_error_message() ); ?></p>
					<p><?php esc_html_e( 'You can still proceed, but compatibility cannot be verified.', 'wp-s3-backup' ); ?></p>
				</div>
			<?php else : ?>
				<table class="widefat striped" style="max-width: 600px;">
					<tbody>
						<tr>
							<th><?php esc_html_e( 'Backup Date', 'wp-s3-backup' ); ?></th>
							<td><?php echo esc_html( isset( $manifest['timestamp'] ) ? $manifest['timestamp'] : $timestamp ); ?></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Site URL', 'wp-s3-backup' ); ?></th>
							<td><?php echo esc_html( isset( $manifest['site_url'] ) ? $manifest['site_url'] : 'Unknown' ); ?></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'WordPress Version', 'wp-s3-backup' ); ?></th>
							<td>
								<?php echo esc_html( isset( $manifest['wordpress_version'] ) ? $manifest['wordpress_version'] : 'Unknown' ); ?>
								→ <?php echo esc_html( get_bloginfo( 'version' ) ); ?> (<?php esc_html_e( 'current', 'wp-s3-backup' ); ?>)
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'PHP Version', 'wp-s3-backup' ); ?></th>
							<td>
								<?php echo esc_html( isset( $manifest['php_version'] ) ? $manifest['php_version'] : 'Unknown' ); ?>
								→ <?php echo esc_html( phpversion() ); ?> (<?php esc_html_e( 'current', 'wp-s3-backup' ); ?>)
							</td>
						</tr>
						<?php if ( isset( $manifest['backup_contents']['database'] ) ) : ?>
						<tr>
							<th><?php esc_html_e( 'Database', 'wp-s3-backup' ); ?></th>
							<td>
								<?php
								printf(
									/* translators: 1: Number of tables, 2: Number of rows, 3: File size */
									esc_html__( '%1$d tables, %2$s rows (%3$s)', 'wp-s3-backup' ),
									$manifest['backup_contents']['database']['tables'],
									number_format( $manifest['backup_contents']['database']['rows'] ),
									size_format( $manifest['backup_contents']['database']['size'] )
								);
								?>
							</td>
						</tr>
						<?php endif; ?>
						<?php if ( isset( $manifest['backup_contents']['files'] ) ) : ?>
						<tr>
							<th><?php esc_html_e( 'Files', 'wp-s3-backup' ); ?></th>
							<td>
								<?php
								printf(
									/* translators: 1: Number of files, 2: File size */
									esc_html__( '%1$s files (%2$s)', 'wp-s3-backup' ),
									number_format( $manifest['backup_contents']['files']['total_files'] ),
									size_format( $manifest['backup_contents']['files']['size'] )
								);
								?>
							</td>
						</tr>
						<?php endif; ?>
					</tbody>
				</table>

				<?php if ( ! empty( $warnings ) ) : ?>
					<div class="notice notice-warning" style="max-width: 600px; margin-top: 15px;">
						<p><strong><?php esc_html_e( 'Compatibility Warnings:', 'wp-s3-backup' ); ?></strong></p>
						<ul style="list-style: disc; margin-left: 20px;">
							<?php foreach ( $warnings as $warning ) : ?>
								<li><?php echo esc_html( $warning ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
			<?php endif; ?>

			<div style="margin-top: 20px;">
				<form method="post" style="display: inline;">
					<?php wp_nonce_field( 'wps3b_confirm_restore', 'wps3b_restore_nonce' ); ?>
					<input type="hidden" name="wps3b_restore_timestamp" value="<?php echo esc_attr( $timestamp ); ?>" />
					<button type="submit" name="wps3b_confirm_restore" class="button button-primary wps3b-restore-btn"
						onclick="return confirm('<?php esc_attr_e( 'Are you absolutely sure? This cannot be undone.', 'wp-s3-backup' ); ?>');">
						<?php esc_html_e( 'Confirm Restore', 'wp-s3-backup' ); ?>
					</button>
				</form>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wps3b_backups' ) ); ?>" class="button button-secondary">
					<?php esc_html_e( 'Cancel', 'wp-s3-backup' ); ?>
				</a>
			</div>
		</div>

	<?php else : ?>

		<!-- Backup Now -->
		<form method="post" style="margin-bottom: 20px;">
			<?php wp_nonce_field( 'wps3b_backup_now', 'wps3b_backup_nonce' ); ?>
			<button type="submit" name="wps3b_backup_now" class="button button-primary">
				<?php esc_html_e( 'Create Backup Now', 'wp-s3-backup' ); ?>
			</button>
		</form>

		<?php if ( $error ) : ?>
			<div class="notice notice-error">
				<p><?php echo esc_html( $error ); ?></p>
			</div>
		<?php elseif ( empty( $backups ) ) : ?>
			<div class="notice notice-info">
				<p><?php esc_html_e( 'No backups found in S3. Click "Create Backup Now" to create your first backup.', 'wp-s3-backup' ); ?></p>
			</div>
		<?php else : ?>
			<table class="widefat striped wps3b-backups-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Date', 'wp-s3-backup' ); ?></th>
						<th><?php esc_html_e( 'Files', 'wp-s3-backup' ); ?></th>
						<th><?php esc_html_e( 'Total Size', 'wp-s3-backup' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'wp-s3-backup' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $backups as $backup ) : ?>
					<tr>
						<td>
							<strong><?php echo esc_html( $backup['date'] ); ?></strong>
						</td>
						<td>
							<?php
							foreach ( $backup['files'] as $file ) :
								$basename = basename( $file['key'] );
								$download_url = wp_nonce_url(
									add_query_arg( array(
										'page'           => 'wps3b_backups',
										'wps3b_download' => rawurlencode( $file['key'] ),
									), admin_url( 'admin.php' ) ),
									'wps3b_download_backup'
								);
							?>
								<div class="wps3b-file-item">
									<a href="<?php echo esc_url( $download_url ); ?>" title="<?php esc_attr_e( 'Download', 'wp-s3-backup' ); ?>">
										<?php echo esc_html( $basename ); ?>
									</a>
									<span class="wps3b-file-size">(<?php echo esc_html( size_format( $file['size'] ) ); ?>)</span>
								</div>
							<?php endforeach; ?>
						</td>
						<td><?php echo esc_html( size_format( $backup['total_size'] ) ); ?></td>
						<td>
							<?php
							$restore_url = wp_nonce_url(
								add_query_arg( array(
									'page'          => 'wps3b_backups',
									'wps3b_restore' => rawurlencode( $backup['timestamp'] ),
								), admin_url( 'admin.php' ) ),
								'wps3b_restore_backup'
							);
							$delete_url = wp_nonce_url(
								add_query_arg( array(
									'page'         => 'wps3b_backups',
									'wps3b_delete' => rawurlencode( $backup['timestamp'] ),
								), admin_url( 'admin.php' ) ),
								'wps3b_delete_backup'
							);
							?>
							<a href="<?php echo esc_url( $restore_url ); ?>" class="button button-small">
								<?php esc_html_e( 'Restore', 'wp-s3-backup' ); ?>
							</a>
							<a href="<?php echo esc_url( $delete_url ); ?>"
							   class="wps3b-delete-link"
							   onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this backup?', 'wp-s3-backup' ); ?>');">
								<?php esc_html_e( 'Delete', 'wp-s3-backup' ); ?>
							</a>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p class="description">
				<?php
				printf(
					/* translators: Number of backups */
					esc_html__( '%d backup(s) found in S3.', 'wp-s3-backup' ),
					count( $backups )
				);
				?>
			</p>
		<?php endif; ?>

	<?php endif; ?>
</div>
